#pragma once
#include <string>
#include "degree.h"
using namespace std;

class Student {
private:
	string studentId = "";
	string firstName = "";
	string lastName = "";
	string email = "";
	int age = 0;
	int daysInCourse[3] = { 0, 0, 0 };
	DegreeProgram degreeProgram;

public:
	//constructor
	Student();
	Student(string studentId, string firstName, string lastName, string email, int age, int dayInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram);
	//destructor
	~Student();
	//function declarations
	//accessors
	string getStudentId() const;
	string getFirstName() const;
	string getLastName() const;
	string getEmail() const;
	int getAge() const;
	int getDaysInCourse1() const;
	int getDaysInCourse2() const;
	int getDaysInCourse3() const;
	DegreeProgram getDegreeProgram() const;
	//mutators
	void setStudentId(string studentId);
	void setFirstName(string firstName);
	void setLastName(string lastName);
	void setEmail(string email);
	void setAge(int age);
	void setDays(int* days);
	void setDegreeProgram(DegreeProgram degree);

	//print
	void print();




};