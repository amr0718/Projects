#include <iostream>
#include <string>
#include "roster.h"
using namespace std;


int main() {

	const string studentData[] =
	{
		"A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
		"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
		"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
		"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
		"A5,Andrea,Ruotolo,aruoto1@wgu.edu,35,45,8,9, SOFTWARE"
	};

	cout << "C867: Scripting and Programming, C++" << endl;
	cout << "Andrea Ruotolo" << endl;
	cout << "Student ID: 012886615" << endl << endl;


	Roster* classRoster = new Roster();

	for (int i = 0; i < 5; i++) {
		classRoster->parse(studentData[i]);
	}

	classRoster->printAll();
	classRoster->printInvalidEmails();

	cout << "Average Days in Course" << endl;
	for (int i = 0; i < 5; i++) {
		classRoster->printDays(classRoster->getStudentId(i));
	}
	cout << endl;

	classRoster->printByDegreeProgram(SOFTWARE);
	classRoster->remove("A3");
	classRoster->printAll();
	classRoster->remove("A3");
	classRoster->~Roster();
}