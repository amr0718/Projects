#include <string>
#include <iostream>
#include "student.h"
using namespace std;

//constructor
Student::Student() {
	studentId = "";
	firstName = "";
	lastName = "";
	email = "";
	age = -1;
	int daysInCourse[3] = { -1, -1, -1 };
	degreeProgram = static_cast<DegreeProgram>(0);


}
Student::Student(string studentId, string firstName, string lastName, string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeProgram) {
	this->studentId = studentId;
	this->firstName = firstName;
	this->lastName = lastName;
	this->email = email;
	this->age = age;
	//for (int i = 0; i < 3; i++) {
	//	this->daysInCourse[i] = daysInCourse[i];
	//}
	this->daysInCourse[3];
	daysInCourse[0] = daysInCourse1;
	daysInCourse[1] = daysInCourse2;
	daysInCourse[2] = daysInCourse3;
	this->degreeProgram = degreeProgram;

}

//destructor
Student::~Student() {}

//function declaration
//accessors
string Student::getStudentId()const { return studentId; }
string Student::getFirstName()const { return firstName; }
string Student::getLastName()const { return lastName; }
string Student::getEmail()const { return email; }
int Student::getAge()const { return age; }
int Student::getDaysInCourse1() const { return daysInCourse[0]; }
int Student::getDaysInCourse2() const { return daysInCourse[1]; }
int Student::getDaysInCourse3() const { return daysInCourse[2]; }
DegreeProgram Student::getDegreeProgram() const { return degreeProgram; }

//mutators
void Student::setStudentId(string id) {
	id = studentId;
	return;
}
void Student::setFirstName(string fn) {
	firstName = fn;
	return;
}
void Student::setLastName(string ln) {
	lastName = ln;
	return;
}
void Student::setEmail(string em) {
	email = em;
	return;
}
void Student::setAge(int a) {
	a = age;
	return;
}
void Student::setDays(int* days) {
	for (int i = 0; i < 3; i++) {
		daysInCourse[i] = days[i];
	}
}

void Student::setDegreeProgram(DegreeProgram degreeProgram)
{
	this->degreeProgram = degreeProgram;
}



void Student::print() {

	string degreeProg = "SOFTWARE";
	if (getDegreeProgram() == DegreeProgram::NETWORK) degreeProg = "NETWORK";
	if (getDegreeProgram() == DegreeProgram::SECURITY) degreeProg = "SECURITY";
	cout << getStudentId() << "\tFirst Name: " << getFirstName() << "\tLast Name: " << getLastName() << "\tAge: " << getAge() << "\tDays In Course: {" << getDaysInCourse1() << ", " << getDaysInCourse2() << ", " << getDaysInCourse3() << "}" << "\tDegree Program: " << degreeProg << endl;
}

