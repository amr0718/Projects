#include "roster.h"
#include <iostream>
#include <string>
#include "student.h"
using namespace std;



int Roster::nextIndex = 0;


Roster::Roster() {
	classRosterArray = new Student[5];
}


void Roster::parse(string data)
{
	size_t rhs = data.find(",");
	string studentId = data.substr(0, rhs);

	size_t lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string firstName = data.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string lastName = data.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string email = data.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int age = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int daysInCourse1 = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int daysInCourse2 = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int daysInCourse3 = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string typeStr = data.substr(lhs, rhs - lhs);
	DegreeProgram degreeProgram = DegreeProgram::SOFTWARE;
	if (typeStr == "NETWORK") {
		degreeProgram = DegreeProgram::NETWORK;
	}
	else if (typeStr == "SECURITY") {
		degreeProgram = DegreeProgram::SECURITY;
	}

	add(studentId, firstName, lastName, email, age, daysInCourse1, daysInCourse2, daysInCourse3, degreeProgram);

}

void Roster::add(string studentId, string firstName, string lastName, string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeProgram)
{
	Student s(studentId, firstName, lastName, email, age, daysInCourse1, daysInCourse2, daysInCourse3, degreeProgram);
	classRosterArray[nextIndex++] = s;
}

void Roster::remove(string studentId)
{
	cout << "Removing " << studentId << endl;
	bool found = false;

	for (int i = 0; i < nextIndex; ++i) {
		if (classRosterArray[i].getStudentId() == studentId) {
			found = true;
			classRosterArray[i] = classRosterArray[nextIndex - 1];
			nextIndex--;
			break;
		}

	}
	if (!found) {
		cout << "Student with id " << studentId << " not found!" << endl;
	}
}



void Roster::printAll()
{
	for (int i = 0; i < nextIndex; ++i) {
		classRosterArray[i].print();
	}
}

void Roster::printDays(string studentId)
{

	for (int i = 0; i < nextIndex; i++) {
		if (classRosterArray[i].getStudentId() == studentId) {
			double averageDays = (classRosterArray[i].getDaysInCourse1() + classRosterArray[i].getDaysInCourse2() + classRosterArray[i].getDaysInCourse3()) / 3.00;

			cout << studentId << ": " << averageDays << endl;
		}
	}
}

void Roster::printInvalidEmails() {
	for (int i = 0; i < nextIndex; i++) {
		string email = classRosterArray[i].getEmail();
		if (email.find('@') == string::npos || email.find('.') == string::npos || email.find(' ') != string::npos) {
			cout << "Invalid email: " << email << endl;
		}
	}
	cout << endl;
}

void Roster::printByDegreeProgram(DegreeProgram degreeProgram)
{
	cout << "Degree Program" << endl;
	for (int i = 0; i < nextIndex; i++) {
		if (classRosterArray[i].getDegreeProgram() == degreeProgram) {
			classRosterArray[i].print();
		}
	}
}

string Roster::getStudentId(int index)
{
	return classRosterArray[index].getStudentId();
}

Roster::~Roster() {
	delete[] classRosterArray;
}
