#pragma once
#include <string>
#include "student.h"
using namespace std;

class Roster {
private:
	Student* classRosterArray;
	static int nextIndex;

public:
	Roster();
	~Roster();
	void parse(string);
	void add(string studentId, string firstName, string lastName, string email, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreProgram);
	void remove(string);
	void printAll();
	void printDays(string);
	void printInvalidEmails();
	void printByDegreeProgram(DegreeProgram);
	string getStudentId(int index);

};